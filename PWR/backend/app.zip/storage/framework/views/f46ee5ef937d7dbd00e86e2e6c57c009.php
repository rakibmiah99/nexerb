<div class="row">
    <p><?php echo e(json_encode($course_topic)); ?></p>
</div>
<?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/course-topic/show.blade.php ENDPATH**/ ?>