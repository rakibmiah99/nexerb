<!DOCTYPE html>
    <html
        lang="<?php echo e(app()->getLocale() == "en" ? 'en' : 'ar'); ?>"
        dir="<?php echo e(app()->getLocale() == "en" ? 'ltr' : 'rtl'); ?>"
        class="<?php echo e(session('theme') == "light" ? 'light-style' : 'dark-style'); ?> layout-menu-fixed"

        data-theme="theme-default"
        data-assets-path="../assets/"
        data-template="vertical-menu-template"
    >
    <head>
        <title><?php echo e(isset($title) ? $title : 'My Project Title'); ?> </title>
        <meta charset="utf-8" />
        <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </head>

<body>
<!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">

        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Layout container -->
        <div class="layout-page">
            <!-- Navbar -->

            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- / Navbar -->

            <!-- Content wrapper -->
            <div class="content-wrapper position-relative">
                <!-- Content -->

                <?php echo $__env->yieldContent('content'); ?>

                <div class="mt-2"></div>
                <footer  style="bottom: 0" class="content-footer w-100 position-fixed footer bg-footer-theme">
                    <div class="container-xxl d-flex flex-wrap justify-content-center py-1 flex-md-row flex-column">
                        <div style="margin-left: -200px" class="mb-2 text-center mb-md-0">
                            ©
                            <script>
                                document.write(new Date().getFullYear());
                            </script>
                            , This Application Made By
                            <a href="https://tazamun.com.sa" target="_blank" class="footer-link fw-bolder text-primary">Nexerb Limited</a>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
    </div>
    <?php if (isset($component)) { $__componentOriginal37b7f052626c638ba0443fdb400d6f57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal37b7f052626c638ba0443fdb400d6f57 = $attributes; } ?>
<?php $component = App\View\Components\DeleteModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('delete-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DeleteModal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal37b7f052626c638ba0443fdb400d6f57)): ?>
<?php $attributes = $__attributesOriginal37b7f052626c638ba0443fdb400d6f57; ?>
<?php unset($__attributesOriginal37b7f052626c638ba0443fdb400d6f57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal37b7f052626c638ba0443fdb400d6f57)): ?>
<?php $component = $__componentOriginal37b7f052626c638ba0443fdb400d6f57; ?>
<?php unset($__componentOriginal37b7f052626c638ba0443fdb400d6f57); ?>
<?php endif; ?>
    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>
</div>
<!-- / Layout wrapper -->

    <!-- Core JS -->
    <script src="<?php echo e(asset("assets/vendor/js/menu.js")); ?>"></script>
    <!-- endbuild -->

    <!-- Main JS -->
    <script src="<?php echo e(asset("assets/js/main.js")); ?>"></script>

    <!-- Page JS -->
    <script src="<?php echo e(asset("assets/js/dashboards-analytics.js")); ?>"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>

    <script>
        let timeout = null;
        function searchData(){
            clearTimeout(timeout);
            timeout = setTimeout(function (){
                $('#search-form').trigger('submit');
            }, 500)
        }


        $(document).ready(function() {
            $('.select-2').select2();
        });


        //delete modal from index list button
        $('.delete-btn').on('click', function (){
            let url = $(this).attr('url')
            $('#modal-delete-form').attr('action', url)
        });
    </script>
</body>
</html>
<?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/layouts/app.blade.php ENDPATH**/ ?>