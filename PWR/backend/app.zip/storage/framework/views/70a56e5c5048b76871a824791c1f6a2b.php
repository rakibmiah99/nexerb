<?php if($attributes->get('visibility')): ?>
    <!-- Layouts -->
    <li class="menu-item <?php echo e($attributes->get('active') ? 'active open' : ''); ?>">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
            <i class="menu-icon tf-icons bi <?php echo e($attributes->get('bi-icon')); ?>"></i>
            <div data-i18n="Layouts"><?php echo e($attributes->get('name')); ?></div>
        </a>

        <ul class="menu-sub">
            <?php $__currentLoopData = $attributes->get('child'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(key_exists('visibility', $item) && $item['visibility']): ?>
                    <li class="menu-item <?php echo e(array_key_exists('active', $item) && $item['active'] ? 'active' : ''); ?>">
                        <a href="<?php echo e($item['url']); ?>" class="menu-link">
                            <div data-i18n="Without menu"><?php echo e($item['name']); ?></div>
                        </a>
                    </li>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
<?php endif; ?>
<?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/components/menu-item-dropdown.blade.php ENDPATH**/ ?>