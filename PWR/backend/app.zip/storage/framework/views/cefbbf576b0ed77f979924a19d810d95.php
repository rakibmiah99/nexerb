<?php if($attributes->get('data-length') === 0): ?>
    <div class="h-100 w-100 text-center mt-5">
        <i class="bi bi-database me-1 d-inline-block"></i>
        <b>No Data Found!</b>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/components/when-table-empty.blade.php ENDPATH**/ ?>