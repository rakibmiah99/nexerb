<?php
    $mode = $attributes->get('mode') ?? 'horizontal'; //vertical,horizontal
    $name = $attributes->get('name');
    $size = $attributes->get('size');
    $title = $attributes->get('title');
    $after_label = $attributes->get('after-label');
    $value = $attributes->get('value');
    $min = $attributes->get('min');
    $max = $attributes->get('max');
    $rows = $attributes->get('rows');
    $cols = $attributes->get('cols');
    $type = $attributes->get('type') ?? "text";
    $input_size = "";
    $label_size = "";
    if ($mode == "horizontal"){
        $input_size = $attributes->get('input-size') ?? 'col-md-10';
        $label_size = $attributes->get('label-size') ?? 'col-md-2';
    }

    $required = $attributes->get('required') ?? false;
    $readonly = $attributes->get('readonly') ?? false;
    $disabled = $attributes->get('disabled') ?? false;

?>
<div class="mb-3 <?php echo e($mode == 'horizontal' ? 'row' : ''); ?>" >
    <label <?php if($size): ?> style="font-size: 10px"  <?php endif; ?> for="<?php echo e($name); ?>" class="<?php echo e($label_size); ?> col-form-label">
        <?php echo e($title); ?>

        <?php echo $after_label; ?>
        <?php if($required): ?>
            <?php if (isset($component)) { $__componentOriginalbba606fec37ea04333bc269e3e165587 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbba606fec37ea04333bc269e3e165587 = $attributes; } ?>
<?php $component = App\View\Components\Required::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('required'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Required::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbba606fec37ea04333bc269e3e165587)): ?>
<?php $attributes = $__attributesOriginalbba606fec37ea04333bc269e3e165587; ?>
<?php unset($__attributesOriginalbba606fec37ea04333bc269e3e165587); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbba606fec37ea04333bc269e3e165587)): ?>
<?php $component = $__componentOriginalbba606fec37ea04333bc269e3e165587; ?>
<?php unset($__componentOriginalbba606fec37ea04333bc269e3e165587); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal824404ceeb4a1e7de17bfcaedf377360 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal824404ceeb4a1e7de17bfcaedf377360 = $attributes; } ?>
<?php $component = App\View\Components\InputError::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\InputError::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($name).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal824404ceeb4a1e7de17bfcaedf377360)): ?>
<?php $attributes = $__attributesOriginal824404ceeb4a1e7de17bfcaedf377360; ?>
<?php unset($__attributesOriginal824404ceeb4a1e7de17bfcaedf377360); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal824404ceeb4a1e7de17bfcaedf377360)): ?>
<?php $component = $__componentOriginal824404ceeb4a1e7de17bfcaedf377360; ?>
<?php unset($__componentOriginal824404ceeb4a1e7de17bfcaedf377360); ?>
<?php endif; ?>
        <?php endif; ?>
    </label>
    <div class="<?php echo e($input_size); ?> ">
        <?php if($type != "text-area"): ?>
            <input
                <?php if($required): ?> required <?php endif; ?>
                <?php if($readonly): ?> readonly <?php endif; ?>
                <?php if($disabled): ?> disabled <?php endif; ?>
                class="form-control <?php echo e($size); ?>" name="<?php echo e($name); ?>"
                type="<?php echo e($type); ?>"
                value="<?php echo e($value); ?>"
                id="<?php echo e($name); ?>"
                <?php if($min): ?> min="<?php echo e($min); ?>" <?php endif; ?>
                <?php if($max): ?> max="<?php echo e($max); ?>" <?php endif; ?>
            >
        <?php else: ?>
            <textarea
                <?php if($required): ?> required <?php endif; ?>
                <?php if($readonly): ?> readonly <?php endif; ?>
                <?php if($disabled): ?> disabled <?php endif; ?>
                class="form-control <?php echo e($size); ?>" name="<?php echo e($name); ?>"
                id="<?php echo e($name); ?>"
                <?php if($rows): ?> rows="<?php echo e($rows); ?>" <?php endif; ?>
                <?php if($cols): ?> cols="<?php echo e($cols); ?>" <?php endif; ?>
            ><?php echo $value; ?></textarea>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/components/input.blade.php ENDPATH**/ ?>