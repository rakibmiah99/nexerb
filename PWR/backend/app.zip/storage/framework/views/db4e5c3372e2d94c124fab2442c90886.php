<?php
    $segment1 = request()->segment(1);
?>

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a href="#" class="app-brand-link">
          <span class="app-brand-logo demo">
            <img height="50px" src="<?php echo e(asset('assets/logo.png')); ?>"/>
          </span>
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>

    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">
        <?php if (isset($component)) { $__componentOriginal16c5b89192469ba970d54fc9b83541bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16c5b89192469ba970d54fc9b83541bc = $attributes; } ?>
<?php $component = App\View\Components\MenuItem::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MenuItem::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'bx bx-grid-alt bx-sm','url' => '#','name' => 'Dashboard']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16c5b89192469ba970d54fc9b83541bc)): ?>
<?php $attributes = $__attributesOriginal16c5b89192469ba970d54fc9b83541bc; ?>
<?php unset($__attributesOriginal16c5b89192469ba970d54fc9b83541bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16c5b89192469ba970d54fc9b83541bc)): ?>
<?php $component = $__componentOriginal16c5b89192469ba970d54fc9b83541bc; ?>
<?php unset($__componentOriginal16c5b89192469ba970d54fc9b83541bc); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal06e370d259f4ddbcda7853e27f938422 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06e370d259f4ddbcda7853e27f938422 = $attributes; } ?>
<?php $component = App\View\Components\MenuItemDropdown::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu-item-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MenuItemDropdown::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bi-icon' => 'bi-building-gear','name' => 'Course Management','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($segment1 == 'course' || $segment1 == 'course-topic' || $segment1 == 'course-topic-data' || $segment1 == 'course-topic-resource' ),'visibility' => true,'child' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                [
                    'visibility' => true,
                    'active' => request()->routeIs('course.index'),
                    'url' => route('course.index'),
                    'name' => 'Course'
                ],
                [
                    'visibility' => true,
                    'active' => request()->routeIs('course_topic.index') || request()->routeIs('course_topic.edit') || request()->routeIs('course_topic.create'),
                    'url' => route('course_topic.index'),
                    'name' => 'Course Topic'
                ],
                [
                    'visibility' => true,
                    'active' => request()->routeIs('course_topic_data.index') || request()->routeIs('course_topic_data.edit') || request()->routeIs('course_topic_data.create'),
                    'url' => route('course_topic_data.index'),
                    'name' => 'Course Topic Data'
                ],
                [
                    'visibility' => true,
                    'active' => request()->routeIs('course_topic_resource.index') || request()->routeIs('course_topic_resource.edit') || request()->routeIs('course_topic_resource.create'),
                    'url' => route('course_topic_resource.index'),
                    'name' => 'Course Topic Resource'
                ],
            ]
        )]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06e370d259f4ddbcda7853e27f938422)): ?>
<?php $attributes = $__attributesOriginal06e370d259f4ddbcda7853e27f938422; ?>
<?php unset($__attributesOriginal06e370d259f4ddbcda7853e27f938422); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06e370d259f4ddbcda7853e27f938422)): ?>
<?php $component = $__componentOriginal06e370d259f4ddbcda7853e27f938422; ?>
<?php unset($__componentOriginal06e370d259f4ddbcda7853e27f938422); ?>
<?php endif; ?>

    </ul>


</aside>
<!-- / Menu -->
<?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>