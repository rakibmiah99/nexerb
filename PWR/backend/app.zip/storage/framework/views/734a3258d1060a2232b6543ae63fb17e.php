<?php $__env->startSection('content'); ?>
    <div class="p-4">
        <div class="card">
            <?php if (isset($component)) { $__componentOriginal45b0c9ba26fcd16a79034c21758ffbac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45b0c9ba26fcd16a79034c21758ffbac = $attributes; } ?>
<?php $component = App\View\Components\CardHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CardHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['can-create' => true,'url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('course_topic_resource.create')),'name' => 'Course Topic Resource','url-name' => 'Create']); ?>
                 <?php $__env->slot('buttons', null, []); ?> 
                    <form action="<?php echo e(route('course_topic_resource.index')); ?>" class="d-flex">
                        <div class="me-3">
                            <select name="course-id" class="form-control form-control-sm">
                                <option value="">select course</option>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if(request()->get('course-id') == $item->id): ?> selected <?php endif; ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="me-3">
                            <select name="course-topic-id"  class="form-control form-control-sm">
                                <option value="">select course topic</option>
                            </select>
                        </div>

                        <div class="me-3">
                            <button type="submit" class="btn btn-sm btn-primary">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                    </form>

                    <script>
                        $('select[name=course-id]').on('change', function (){
                            let course_id = $(this).val();
                            getCourseWiseTopic(course_id)
                        })

                        <?php if($course_id = request()->get('course-id')): ?>
                            getCourseWiseTopic('<?php echo e($course_id); ?>')
                        <?php endif; ?>


                        function getCourseWiseTopic(course_id){
                            let course_topic_el = $('select[name=course-topic-id]')
                            course_topic_el.empty();
                            course_topic_el.append(`<option value="">select course topic</option>`)
                            let route = "<?php echo e(route('course.get_topics', 'x')); ?>".replace('x', course_id)
                            axios.get(route).then(function (response){
                                data = response.data;
                                let route_course_id = '<?php echo e(request()->get('course-topic-id')); ?>'
                                data.forEach(function (item){
                                    course_topic_el.append(`<option ${route_course_id == item.id ? 'selected' : ''}  value="${item.id}">${item.name}</option>`)
                                })
                            }).catch(function (error){

                            })
                        }
                    </script>

                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45b0c9ba26fcd16a79034c21758ffbac)): ?>
<?php $attributes = $__attributesOriginal45b0c9ba26fcd16a79034c21758ffbac; ?>
<?php unset($__attributesOriginal45b0c9ba26fcd16a79034c21758ffbac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45b0c9ba26fcd16a79034c21758ffbac)): ?>
<?php $component = $__componentOriginal45b0c9ba26fcd16a79034c21758ffbac; ?>
<?php unset($__componentOriginal45b0c9ba26fcd16a79034c21758ffbac); ?>
<?php endif; ?>
            <div class="mt-3">
                

                <div class="table-responsive table-paginate mt-2 text-nowrap">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Title</th>
                            <th>Course</th>
                            <th>Topic</th>
                            <th>Info Type</th>
                            <th>Show In</th>
                            <th>Paid Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                        <?php $index = \App\Helper::PageIndex() ?>
                        <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index++); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->course->name); ?></td>
                                <td><?php echo e($item->course_topic->name); ?></td>
                                <td><?php echo e($item->info_type); ?></td>
                                <td><?php echo e($item->show_in); ?></td>
                                <td>
                                    <?php if($item->is_paid): ?>
                                        <span class="badge bg-dark">Paid</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Free</span>
                                    <?php endif; ?>
                                </td>


                                <td>
                                    <div class="dropdown">
                                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="bx bx-dots-vertical-rounded"></i>
                                        </button>


                                        <div class="dropdown-menu" style="">
                                            <a data-bs-toggle="modal" data-bs-target="#viewModal" class="dropdown-item view-btn" href="javascript:void(0);" url="<?php echo e(route('course_topic_resource.show', $item->id)); ?>"><i class='bx bx-low-vision me-1'></i>View</a>
                                            <a class="dropdown-item" href="<?php echo e(route('course_topic_resource.edit', $item->id)); ?>"><i class="bx bx-edit-alt me-1"></i>Edit</a>

                                            <a data-bs-toggle="modal" data-bs-target="#deleteModal" url="<?php echo e(route('course_topic_resource.delete', $item->id)); ?>"  class="dropdown-item delete-btn" href="javascript:void(0);"><i class="bx bx-trash me-1"></i>Delete</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php if (isset($component)) { $__componentOriginal0eb8f061941d23b568fe935d22b99e71 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0eb8f061941d23b568fe935d22b99e71 = $attributes; } ?>
<?php $component = App\View\Components\WhenTableEmpty::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('when-table-empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\WhenTableEmpty::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-length' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($resources->count())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0eb8f061941d23b568fe935d22b99e71)): ?>
<?php $attributes = $__attributesOriginal0eb8f061941d23b568fe935d22b99e71; ?>
<?php unset($__attributesOriginal0eb8f061941d23b568fe935d22b99e71); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0eb8f061941d23b568fe935d22b99e71)): ?>
<?php $component = $__componentOriginal0eb8f061941d23b568fe935d22b99e71; ?>
<?php unset($__componentOriginal0eb8f061941d23b568fe935d22b99e71); ?>
<?php endif; ?>
                </div>


                <div class="px-3 mt-3">
                    <?php echo e($resources->links()); ?>

                </div>
            </div>
        </div>
    </div>



    <?php if (isset($component)) { $__componentOriginald66ccc801d5b7ed5e1a00936b7879217 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald66ccc801d5b7ed5e1a00936b7879217 = $attributes; } ?>
<?php $component = App\View\Components\ViewModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('view-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ViewModal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Show User','size' => 'modal-xl']); ?>
        <div id="modal-body"></div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald66ccc801d5b7ed5e1a00936b7879217)): ?>
<?php $attributes = $__attributesOriginald66ccc801d5b7ed5e1a00936b7879217; ?>
<?php unset($__attributesOriginald66ccc801d5b7ed5e1a00936b7879217); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald66ccc801d5b7ed5e1a00936b7879217)): ?>
<?php $component = $__componentOriginald66ccc801d5b7ed5e1a00936b7879217; ?>
<?php unset($__componentOriginald66ccc801d5b7ed5e1a00936b7879217); ?>
<?php endif; ?>

    <script>

        $('.view-btn').on('click', function (){
            modalLoaderON();
            let url = $(this).attr('url')
            axios({
                method: 'get',
                url: url
            })
                .then(function (response){
                    modalLoaderOFF();
                    const data = response.data;
                    $('#modal-body').html(data);
                })
                .catch(function (error){

                });
        })

    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/course-topic-resource/index.blade.php ENDPATH**/ ?>