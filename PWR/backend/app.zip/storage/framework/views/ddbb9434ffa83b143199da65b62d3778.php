<div class="d-flex pe-4 justify-content-between align-items-center">
    <h5 class="card-header"><?php echo e($attributes->get('name')); ?></h5>

    <div>
        <?php echo e($slot); ?>

    </div>

    <?php if($attributes->get('can-create')): ?>
        <div class="d-flex align-items-center">

            <?php if(isset($buttons)): ?>
                <?php echo e($buttons); ?>

            <?php endif; ?>

            <a href="<?php echo e($attributes->get('url')); ?>" type="button" class="btn btn-sm btn-primary">
                <?php echo e($attributes->get('url-name')); ?>

            </a>
        </div>
    <?php endif; ?>


</div>
<hr class="m-0">
<?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/components/card-header.blade.php ENDPATH**/ ?>