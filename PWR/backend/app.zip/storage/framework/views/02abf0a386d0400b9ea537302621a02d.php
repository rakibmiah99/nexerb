<?php $__env->startSection('content'); ?>
    <div class="p-4">
        <div class="card">
            <?php if (isset($component)) { $__componentOriginal45b0c9ba26fcd16a79034c21758ffbac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45b0c9ba26fcd16a79034c21758ffbac = $attributes; } ?>
<?php $component = App\View\Components\CardHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CardHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['can-create' => true,'url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('user.create')),'name' => 'Users','url-name' => 'Create']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45b0c9ba26fcd16a79034c21758ffbac)): ?>
<?php $attributes = $__attributesOriginal45b0c9ba26fcd16a79034c21758ffbac; ?>
<?php unset($__attributesOriginal45b0c9ba26fcd16a79034c21758ffbac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45b0c9ba26fcd16a79034c21758ffbac)): ?>
<?php $component = $__componentOriginal45b0c9ba26fcd16a79034c21758ffbac; ?>
<?php unset($__componentOriginal45b0c9ba26fcd16a79034c21758ffbac); ?>
<?php endif; ?>
            <div class="mt-3">
                

                <div class="table-responsive table-paginate mt-2 text-nowrap">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                        <?php $index = \App\Helper::PageIndex() ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index++); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>

                                <td>
                                    <div class="dropdown">
                                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="bx bx-dots-vertical-rounded"></i>
                                        </button>


                                        <div class="dropdown-menu" style="">
                                            <a data-bs-toggle="modal" data-bs-target="#viewModal" class="dropdown-item view-btn" href="javascript:void(0);" url="<?php echo e(route('user.show', $user->id)); ?>"><i class='bx bx-low-vision me-1'></i>View</a>
                                            <a class="dropdown-item" href="<?php echo e(route('user.edit', $user->id)); ?>"><i class="bx bx-edit-alt me-1"></i>Edit</a>
                                            <a class="dropdown-item" href="<?php echo e(route('user.changeStatus', $user->id)); ?>"><i class='bx bx-checkbox-minus'></i>Active</a>
                                            <a data-bs-toggle="modal" data-bs-target="#deleteModal" url="<?php echo e(route('user.delete', $user->id)); ?>"  class="dropdown-item delete-btn" href="javascript:void(0);"><i class="bx bx-trash me-1"></i>Delete</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php if (isset($component)) { $__componentOriginal0eb8f061941d23b568fe935d22b99e71 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0eb8f061941d23b568fe935d22b99e71 = $attributes; } ?>
<?php $component = App\View\Components\WhenTableEmpty::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('when-table-empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\WhenTableEmpty::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-length' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($users->count())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0eb8f061941d23b568fe935d22b99e71)): ?>
<?php $attributes = $__attributesOriginal0eb8f061941d23b568fe935d22b99e71; ?>
<?php unset($__attributesOriginal0eb8f061941d23b568fe935d22b99e71); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0eb8f061941d23b568fe935d22b99e71)): ?>
<?php $component = $__componentOriginal0eb8f061941d23b568fe935d22b99e71; ?>
<?php unset($__componentOriginal0eb8f061941d23b568fe935d22b99e71); ?>
<?php endif; ?>
                </div>


                <div class="px-3 mt-3">
                    <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    </div>



    <?php if (isset($component)) { $__componentOriginald66ccc801d5b7ed5e1a00936b7879217 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald66ccc801d5b7ed5e1a00936b7879217 = $attributes; } ?>
<?php $component = App\View\Components\ViewModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('view-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ViewModal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Show User','size' => 'modal-xl']); ?>
        <div id="modal-body"></div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald66ccc801d5b7ed5e1a00936b7879217)): ?>
<?php $attributes = $__attributesOriginald66ccc801d5b7ed5e1a00936b7879217; ?>
<?php unset($__attributesOriginald66ccc801d5b7ed5e1a00936b7879217); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald66ccc801d5b7ed5e1a00936b7879217)): ?>
<?php $component = $__componentOriginald66ccc801d5b7ed5e1a00936b7879217; ?>
<?php unset($__componentOriginald66ccc801d5b7ed5e1a00936b7879217); ?>
<?php endif; ?>

    <script>

        $('.view-btn').on('click', function (){
            modalLoaderON();
            let url = $(this).attr('url')
            axios({
                method: 'get',
                url: url
            })
                .then(function (response){
                    modalLoaderOFF();
                    const data = response.data;
                    $('#modal-body').html(data);
                })
                .catch(function (error){

                });
        })

    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/users/index.blade.php ENDPATH**/ ?>