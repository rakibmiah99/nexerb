<?php $is_edit = request()->segment(2) == "edit"  ?>


<?php $__env->startSection('content'); ?>
    <div class="p-4">
        <div class="card">
            <?php if (isset($component)) { $__componentOriginal45b0c9ba26fcd16a79034c21758ffbac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45b0c9ba26fcd16a79034c21758ffbac = $attributes; } ?>
<?php $component = App\View\Components\CardHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CardHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['can-create' => true,'name' => 'Edit User','url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('course.index')),'url-name' => 'Back']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45b0c9ba26fcd16a79034c21758ffbac)): ?>
<?php $attributes = $__attributesOriginal45b0c9ba26fcd16a79034c21758ffbac; ?>
<?php unset($__attributesOriginal45b0c9ba26fcd16a79034c21758ffbac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45b0c9ba26fcd16a79034c21758ffbac)): ?>
<?php $component = $__componentOriginal45b0c9ba26fcd16a79034c21758ffbac; ?>
<?php unset($__componentOriginal45b0c9ba26fcd16a79034c21758ffbac); ?>
<?php endif; ?>
            <form action="<?php echo e(route('course.update', request()->id)); ?>" method="post" class="card-body" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <?php echo $__env->make('course.form_data', compact('is_edit'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="mb-3 row">
                    <label for="html5-datetime-local-input" class="col-md-2 col-form-label"></label>
                    <button type="submit" class="btn btn-primary col-2">
                        Save
                    </button>
                </div>


            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/course/edit.blade.php ENDPATH**/ ?>