<?php
    $mode = $attributes->get('mode') ?? 'horizontal'; //vertical,horizontal
    $name = $attributes->get('name');
    $size = $attributes->get('size');
    $array = $attributes->get('array');
    $column = $attributes->get('column') ?? 'id';
    $display_column = $attributes->get('display_column') ?? 'name';
    $is_required = $attributes->get('is_required');
    $is_multiple = $attributes->get('multiple');
    $id = $attributes->get('id') ?? $name;
    $title = $attributes->get('title');
    $value = $attributes->get('value');
    $input_size = "";
    $label_size = "";
    if ($mode == "horizontal"){
        $input_size = $attributes->get('input-size') ?? 'col-md-10';
        $label_size = $attributes->get('label-size') ?? 'col-md-2';
    }
    //if you want with a code input need following
    $with_code = $attributes->get('with_code');
    $code = $attributes->get('code');

    //if you need multiple with code input box
    $key = $attributes->get('key') ?? 0;
?>


<?php if(!$with_code): ?>

    <div class="mb-3 <?php echo e($mode == "horizontal" ? 'row' : ''); ?>">
        <label <?php if($size): ?> style="font-size: 10px" <?php endif; ?> for="<?php echo e($id); ?>" class="<?php echo e($label_size); ?> col-form-label">
            <?php echo e($title); ?>

            <?php if($is_required): ?>
                <?php if (isset($component)) { $__componentOriginalbba606fec37ea04333bc269e3e165587 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbba606fec37ea04333bc269e3e165587 = $attributes; } ?>
<?php $component = App\View\Components\Required::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('required'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Required::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbba606fec37ea04333bc269e3e165587)): ?>
<?php $attributes = $__attributesOriginalbba606fec37ea04333bc269e3e165587; ?>
<?php unset($__attributesOriginalbba606fec37ea04333bc269e3e165587); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbba606fec37ea04333bc269e3e165587)): ?>
<?php $component = $__componentOriginalbba606fec37ea04333bc269e3e165587; ?>
<?php unset($__componentOriginalbba606fec37ea04333bc269e3e165587); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal824404ceeb4a1e7de17bfcaedf377360 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal824404ceeb4a1e7de17bfcaedf377360 = $attributes; } ?>
<?php $component = App\View\Components\InputError::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\InputError::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($name).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal824404ceeb4a1e7de17bfcaedf377360)): ?>
<?php $attributes = $__attributesOriginal824404ceeb4a1e7de17bfcaedf377360; ?>
<?php unset($__attributesOriginal824404ceeb4a1e7de17bfcaedf377360); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal824404ceeb4a1e7de17bfcaedf377360)): ?>
<?php $component = $__componentOriginal824404ceeb4a1e7de17bfcaedf377360; ?>
<?php unset($__componentOriginal824404ceeb4a1e7de17bfcaedf377360); ?>
<?php endif; ?>
            <?php endif; ?>

        </label>
        <div class="<?php echo e($input_size); ?>">
            <select <?php if($is_multiple): ?> multiple <?php endif; ?> <?php if($is_required): ?> required <?php endif; ?> name="<?php echo e($name); ?>" class="form-select <?php echo e($size); ?> select-2" id="<?php echo e($id); ?>">
                <option value="">Select</option>
                <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->$column); ?>"><?php echo e($item->$display_column); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <?php if($value): ?>
        <script>
            <?php if(isset($is_multiple) && $is_multiple === true): ?>
                $('#<?php echo e($id); ?>').val(<?php echo e(json_encode($value)); ?>);
            <?php else: ?>
                $('#<?php echo e($id); ?>').val(<?php echo e($value); ?>);
            <?php endif; ?>

        </script>
    <?php endif; ?>
<?php endif; ?>



<?php if($with_code): ?>
    <div class="mb-3 <?php echo e($mode == "horizontal" ? 'row' : ''); ?>">
        <label <?php if($size): ?> style="font-size: 10px" <?php endif; ?> for="<?php echo e($name); ?>" class="<?php echo e($mode == "horizontal" ? 'col-md-2' : ''); ?> col-form-label">
            <?php echo e($title); ?>

            <?php if($is_required): ?>
                <?php if (isset($component)) { $__componentOriginalbba606fec37ea04333bc269e3e165587 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbba606fec37ea04333bc269e3e165587 = $attributes; } ?>
<?php $component = App\View\Components\Required::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('required'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Required::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbba606fec37ea04333bc269e3e165587)): ?>
<?php $attributes = $__attributesOriginalbba606fec37ea04333bc269e3e165587; ?>
<?php unset($__attributesOriginalbba606fec37ea04333bc269e3e165587); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbba606fec37ea04333bc269e3e165587)): ?>
<?php $component = $__componentOriginalbba606fec37ea04333bc269e3e165587; ?>
<?php unset($__componentOriginalbba606fec37ea04333bc269e3e165587); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal824404ceeb4a1e7de17bfcaedf377360 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal824404ceeb4a1e7de17bfcaedf377360 = $attributes; } ?>
<?php $component = App\View\Components\InputError::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\InputError::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($name).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal824404ceeb4a1e7de17bfcaedf377360)): ?>
<?php $attributes = $__attributesOriginal824404ceeb4a1e7de17bfcaedf377360; ?>
<?php unset($__attributesOriginal824404ceeb4a1e7de17bfcaedf377360); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal824404ceeb4a1e7de17bfcaedf377360)): ?>
<?php $component = $__componentOriginal824404ceeb4a1e7de17bfcaedf377360; ?>
<?php unset($__componentOriginal824404ceeb4a1e7de17bfcaedf377360); ?>
<?php endif; ?>
            <?php endif; ?>
        </label>
<?php if($mode == "vertical"): ?> <div class="d-flex "> <?php endif; ?>
            <div class="<?php echo e($mode == "horizontal" ? 'col-md-2' : 'w-25'); ?> pe-1">
                <input class="form-control <?php echo e($size ? 'form-control-sm': ''); ?>" type="text" name="<?php echo e($name); ?>-code"  value="<?php echo e($code ?? old($name."-code")); ?>" id="<?php echo e($name); ?>-code">
            </div>
            <div class="<?php echo e($mode == "horizontal" ? 'col-md-8' : 'w-75'); ?>  ps-0">
                <select <?php if($is_multiple): ?> multiple <?php endif; ?> <?php if($is_required): ?> required <?php endif; ?>  name="<?php echo e($name); ?>" class="form-select <?php echo e($size); ?> select-2" id="<?php echo e($name); ?>">
                    <option value=""><?php echo e(__('page.select')); ?></option>
                    <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option code="<?php echo e($item->code); ?>" value="<?php echo e($item->$column); ?>"><?php echo e($item->$display_column); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
<?php if($mode == "vertical"): ?> </div> <?php endif; ?>
    </div>


    <script>
        let selectedEl<?php echo e($key); ?> = $("#<?php echo e($name); ?>");
        selectedEl<?php echo e($key); ?>.on('change', function (){
            let code = $("#<?php echo e($name); ?> :selected").attr('code')
            $('#<?php echo e($name); ?>-code').val(code)
        })

        let keypressTimeout<?php echo e($key); ?> = null;
        $('#<?php echo e($name); ?>-code').on('keyup', function (){
            clearTimeout(keypressTimeout<?php echo e($key); ?>)
            $("#<?php echo e($name); ?> option[value='']").prop('selected', true);
            let code = $(this).val();

            selectedEl<?php echo e($key); ?>.val("")
            $("#<?php echo e($name); ?> option").each(function () {
                let selected = $(this).attr('code');
                let selected_val = $(this).val();
                if (selected == code) {
                    selectedEl<?php echo e($key); ?>.val(selected_val);
                }
            });

            keypressTimeout<?php echo e($key); ?> = setTimeout(function (){
                selectedEl<?php echo e($key); ?>.change();
            }, 500)

        })

        <?php if($value): ?>
            $('#<?php echo e($name); ?>').val(<?php echo e($value); ?>)
            $('#<?php echo e($name); ?>-code').val('<?php echo e($code); ?>')
        <?php endif; ?>


        //input size
        <?php if($size): ?>
            selectedEl<?php echo e($key); ?>.select2();
            // Customizing input size to small
            selectedEl<?php echo e($key); ?>.next('.select2-container').find('.select2-selection--single').css({
                'height': '30px', // Adjust the height as needed
            });
            selectedEl<?php echo e($key); ?>.next('.select2-container').find('.select2-selection--single .select2-selection__rendered').css({
                'line-height': '28px', // Adjust the line height as needed
            });
            selectedEl<?php echo e($key); ?>.next('.select2-container').find('.select2-selection--single .select2-selection__arrow').css({
                'height': '28px', // Adjust the arrow height as needed
            });
        <?php endif; ?>
    </script>
<?php endif; ?>



<?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/components/input-select2.blade.php ENDPATH**/ ?>