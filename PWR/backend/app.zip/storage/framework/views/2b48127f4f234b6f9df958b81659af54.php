<div class="row">
    <p><?php echo e(json_encode($course_topic_data)); ?></p>
</div>
<?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/course-topic-data/show.blade.php ENDPATH**/ ?>