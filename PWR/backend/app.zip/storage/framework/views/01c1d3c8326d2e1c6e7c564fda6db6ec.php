<li class="menu-item ">
    <a href="<?php echo e($attributes->get('url') ?? 'javascript:void(0);'); ?>" class="menu-link">
        <i class="menu-icon tf-icons <?php echo e($attributes->get('icon') ?? 'bx bx-home-circle'); ?>"></i>
        <div data-i18n="Analytics" class="text-capitalize"><?php echo e($attributes->get('name')); ?></div>
    </a>
</li>
<?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/components/menu-item.blade.php ENDPATH**/ ?>