<div class="row">
    <p><?php echo e(json_encode($course)); ?></p>
</div>
<?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\backend\resources\views/course/show.blade.php ENDPATH**/ ?>