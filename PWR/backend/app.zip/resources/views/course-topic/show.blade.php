<div class="row">
    <p>{{json_encode($course_topic)}}</p>
</div>
