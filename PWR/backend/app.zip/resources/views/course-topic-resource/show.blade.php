<div class="row">
    <p>{{json_encode($course_topic_resource)}}</p>
</div>
