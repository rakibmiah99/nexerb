<li class="menu-item ">
    <a href="{{$attributes->get('url') ?? 'javascript:void(0);'}}" class="menu-link">
        <i class="menu-icon tf-icons {{$attributes->get('icon') ?? 'bx bx-home-circle'}}"></i>
        <div data-i18n="Analytics" class="text-capitalize">{{$attributes->get('name')}}</div>
    </a>
</li>
