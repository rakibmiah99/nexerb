<span class="text-danger ms-1">
    @error($attributes->get('name'))
        {{$message}}
    @enderror
</span>
