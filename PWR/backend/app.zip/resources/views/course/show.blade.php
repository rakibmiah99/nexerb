<div class="row">
    <p>{{json_encode($course)}}</p>
</div>
