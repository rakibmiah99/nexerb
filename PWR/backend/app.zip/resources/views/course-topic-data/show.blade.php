<div class="row">
    <p>{{json_encode($course_topic_data)}}</p>
</div>
