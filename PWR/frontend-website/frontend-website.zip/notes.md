# Uses new package 
- markdown-it: for parse markdown data
  - https://github.com/markdown-it/markdown-it?tab=readme-ov-file#install
  - <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/styles/default.min.css">
  - <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/highlight.min.js"></script>
    
  - <script src="https://cdnjs.cloudflare.com/ajax/libs/markdown-it/13.0.1/markdown-it.min.js"></script>
  - <script src="https://cdnjs.cloudflare.com/ajax/libs/markdown-it-highlightjs/3.0.0/markdown-it-highlightjs.min.js"></script>

    
# Read Docs 
  - https://www.jsdelivr.com/package/npm/markdown-it-highlight
  - 
