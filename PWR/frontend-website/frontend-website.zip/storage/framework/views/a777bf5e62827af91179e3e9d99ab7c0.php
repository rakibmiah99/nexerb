<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/styles/default.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?php echo e(asset("assets/vendors/bootstrap/bootstrap.min.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("assets/vendors/animate.min.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("assets/vendors/plyr/plyr.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("assets/css/style.css")); ?>" rel="stylesheet">


<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/highlight.min.js"></script>
<script src="<?php echo e(asset("assets/vendors/bootstrap/bootstrap.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/vendors/markdown-it.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/vendors/jquery.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/vendors/plyr/plyr.js")); ?>"></script>
<script src="<?php echo e(asset("assets/js/common.js")); ?>"></script>
<script>
    const md = window.markdownit();
</script>
<?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\frontend-website\resources\views/layouts/head.blade.php ENDPATH**/ ?>