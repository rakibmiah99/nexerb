<?php $__env->startSection('content'); ?>
    <div class="course-details mt-3">
        <div class="container">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-3 p-2 course-topics">
                        <h5 class="course-topic-title"><?php echo e($course->name); ?></h5>
                        <ul class="nav flex-column">

                            <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item">
                                    <a class="nav-link active" href="<?php echo e(route('course-details', [$course->slug, $topic->slug])); ?>">
                                        <?php if($topic->is_paid): ?>
                                            <i class="bi bi-lock"></i>
                                        <?php elseif($topic->slug == $active_topic->slug): ?>
                                            <i class="bi bi-app-indicator"></i>
                                        <?php else: ?>
                                            <i class="bi bi-app"></i>
                                        <?php endif; ?>
                                        <span> <?php echo e($topic->name); ?> </span>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </ul>
                    </div>

                    <div class="col-md-7 ">
                        <?php if($active_topic->is_paid): ?>
                            <div style="height: 400px; background-image: url(<?php echo e($topic->image); ?>); background-size: cover" class="topic-image position-relative">

                                <div style="background-color: rgba(255, 255, 255, .7)" class="d-flex h-100 align-items-center justify-content-center">
                                    <div class="premium-area w-75 p-4 text-center">
                                        <h5 class="tiro-bangla-regular">এই টিউটোরিয়ালটি পুরোপুরি দেখতে হলে আপনাকে প্রিমিয়াম মেম্বার হতে হবে। টিউটোরিয়ালটি ২১ মিনিটের একটি সম্পূর্ণ গাইড, যা ৪১০৩টি শব্দ নিয়ে গঠিত।</h5>
                                        <div class="mt-2">
                                            <a href="#" class="btn mt-3 btn-brand-secondary me-2">লগ ইন করুন</a>
                                            <h6 class="mt-3 mb-0">অথবা</h6>
                                            <a href="#" class="btn mt-3 btn-brand ms-2">আমাদের প্রিমিয়াম সদস্য হোন </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <?php if($active_topic->play_as == "video"): ?>
                                <div class="video-description">
                                    <div class="plyr__video-embed" id="player">
                                        <iframe
                                            src="https://www.youtube.com/embed/bTqVqk7FSmY?origin=https://plyr.io&amp;iv_load_policy=3&amp;modestbranding=1&amp;playsinline=1&amp;showinfo=0&amp;rel=0&amp;enablejsapi=1"
                                            allowfullscreen
                                            allowtransparency
                                            allow="autoplay"
                                        ></iframe>
                                    </div>
                                </div>

                            <?php elseif($active_topic->play_as == "image"): ?>
                                <div class="video-description">
                                    <img class="img-fluid" src="<?php echo e($topic->image); ?>" alt="<?php echo e($topic->name); ?>">
                                </div>
                            <?php endif; ?>

                        <?php endif; ?>


                        <div class="d-flex p-2 prev-next justify-content-between align-items-center my-2 border-bottom-custom">
                            <a href="<?php if($prev_topic): ?> <?php echo e(route('course-details', [$course->slug, $prev_topic->slug])); ?> <?php endif; ?>" class="btn <?php if(!$prev_topic): ?> disabled <?php endif; ?> btn-brand-secondary ">
                                <i class="bi bi-arrow-left-circle me-2"></i>
                                <span>পূর্ববর্তী</span>
                            </a>
                            <h4 class="fw-bold p-1 mb-0"><?php echo e($active_topic->name); ?></h4>
                            <a href="<?php if($next_topic): ?> <?php echo e(route('course-details', [$course->slug, $next_topic->slug])); ?> <?php endif; ?>" class="btn <?php if(!$next_topic): ?> disabled <?php endif; ?> btn-brand-secondary">
                                <span>পরবর্তী</span>
                                <i class="bi bi-arrow-right-circle me-2"></i>
                            </a>
                        </div>

                        <div class="description-area py-3">
                            <?php if($active_topic->description_type == "text"): ?>
                                <h4><?php echo e($active_topic->name); ?></h4>
                                <div><?php echo $active_topic->description; ?></div>
                            <?php else: ?>
                                <div id="markdown" class=" bg-white text-dark py-2">
                                    <script>
                                        document.write(md.render(<?php echo json_encode($active_topic->description, 15, 512) ?>))
                                    </script>
                                </div>
                            <?php endif; ?>

                            <!-- Active Topic More Docs -->

                            <?php $__currentLoopData = $active_topic_docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <hr>
                                <?php if($docs->description_type == "text"): ?>
                                    <div><?php echo $docs->description; ?></div>
                                <?php else: ?>
                                    <div id="markdown" class=" bg-white text-dark py-2">
                                        <script>
                                            document.write(md.render(<?php echo json_encode($docs->description, 15, 512) ?>))
                                        </script>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>


                    </div>
                    <div class="col-md-2 py-2 course-guide-line-links">
                        <h6 class="course-topic-guideline-title">রিসোর্স এন্ড গাইডলাইন</h6>
                        <ul class="nav flex-column">

                            <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($resource->info_type == "link"): ?>
                                    <li class="nav-item">
                                        <a target="<?php echo e($resource->show_in == "external" ? '_blank' : '_self'); ?>" class="nav-link active" href="<?php echo e($resource->info_type = "link" ? $resource->info : '#'); ?>">
                                            <i class="bi bi-arrow-right-short"></i>
                                            <span> <?php echo e($resource->title); ?> </span>
                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li class="nav-item">
                                        <a class="nav-link active" href="#">
                                            <i class="bi bi-arrow-right-short"></i>
                                            <span> <?php echo e($resource->title); ?> </span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        const player = new Plyr('#player');
        document.querySelectorAll('pre code').forEach((block) => {
            hljs.highlightElement(block);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\frontend-website\resources\views/pages/course-details.blade.php ENDPATH**/ ?>