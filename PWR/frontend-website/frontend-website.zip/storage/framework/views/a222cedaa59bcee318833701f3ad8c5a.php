<div class="banner-search-box">
    <div class="container">
        <div class="container-fluid d-flex justify-content-center align-items-center">
            <div class="d-flex flex-column  align-items-center justify-content-center banner-search-box-area" >
                <input class="form-control w-100 text-center search-box" placeholder="যেকোন কিছু সার্চ করুনঃ লারাভেল গাইডলাইন, কোডিং প্যাটার্ন, ফ্রি রিসোর্স, সার্ভিসিং, নোড জে এস রোডম্যাপ ইত্যাদি">
                <button class="btn mt-2 btn-brand-secondary">সার্চ করুন</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\frontend-website\resources\views/layouts/banner_search.blade.php ENDPATH**/ ?>