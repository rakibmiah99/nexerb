<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.banner_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="courses mt-3">
        <div class="container">
            <div class="container-fluid">
                <div class="row">
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-4">
                            <div class="card" style="width:400px">
                                <img style="height: 220px" class="card-img-top" src="<?php echo e($course->image); ?>" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title course-title"><?php echo e($course->name); ?></h4>
                                    <div class="d-flex align-content-center course-info-icon-text">
                                        <div>
                                            <i class="bi bi-play-btn me-1"></i>
                                            <span> <?php echo e($course->video_count); ?></span>
                                        </div>
                                        <div>
                                            <i class="bi bi-book me-1"></i>
                                            <span><?php echo e($course->word_count); ?></span>
                                        </div>
                                        <div>
                                            <i class="bi bi-calendar me-1"></i>
                                            <span> <?php echo e($course->publish_date); ?></span>
                                        </div>
                                    </div>
                                    <a href="<?php echo e(route('course-details', $course->slug)); ?>" class="btn w-100 btn-light">
                                        <span> বিস্তারিত দেখুন </span>
                                        <i class="bi bi-arrow-right ms-3"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\nexerb-resource\PWR\frontend-website\resources\views/pages/home.blade.php ENDPATH**/ ?>